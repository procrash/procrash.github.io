/**
 * config.js
 * Enthält Konfigurationen und Befehlsdefinitionen für die Wildkamera-App